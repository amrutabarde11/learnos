// ─── controller/SessionController.java ───────────────────────────────────────
package controller;

import engine.EfficiencyEngine;
import engine.EngineResult;
import insights.Insight;
import insights.ProactiveInsightEngine;
import models.*;
import storage.FileManager;

import java.io.IOException;
import java.time.LocalDate;
import java.util.*;

/**
 * SessionController — the single mediator between the UI and everything else.
 *
 * The Dashboard holds ONE reference to this class.
 * It calls methods here. It reads EngineResult and Insights back.
 * It never touches FileManager, agents, or model constructors directly.
 */
public class SessionController {

    private final User                  user;
    private final FileManager           fileManager;
    private final EfficiencyEngine      engine;
    private final ProactiveInsightEngine insightEngine;

    private List<LearningGoal>    goals;
    private List<LearningSession> sessions;
    private EngineResult          result;
    private List<Insight>         insights;

    public SessionController(User user, FileManager fileManager) throws IOException {
        this.user          = user;
        this.fileManager   = fileManager;
        this.engine        = new EfficiencyEngine();
        this.insightEngine = new ProactiveInsightEngine();

        reload();
    }

    /** Reloads all data from storage and reruns the engine. */
    private void reload() throws IOException {
        goals    = fileManager.loadGoals();
        sessions = fileManager.loadSessions();

        // Attach topics and milestones to goals
        List<Topic>     allTopics     = fileManager.loadTopics();
        List<Milestone> allMilestones = fileManager.loadMilestones();

        for (LearningGoal goal : goals) {
            allTopics.stream()
                    .filter(t -> t.getGoalId().equals(goal.getGoalId()))
                    .forEach(goal::addTopic);
            allMilestones.stream()
                    .filter(m -> m.getGoalId().equals(goal.getGoalId()))
                    .forEach(goal::addMilestone);
        }

        result   = engine.process(user, goals, sessions);
        insights = insightEngine.detect(user, goals, sessions, result);
    }

    // ── Session submission ────────────────────────────────────────────────────

    public void submitSession(String goalId, String topicName,
                              double durationHours,
                              MasteryLevel masteryBefore, MasteryLevel masteryAfter,
                              SessionType sessionType, String notes)
            throws IOException {

        if (goalId == null || goalId.isBlank())  throw new IllegalArgumentException("Goal required.");
        if (topicName == null || topicName.isBlank()) throw new IllegalArgumentException("Topic required.");
        if (durationHours <= 0) throw new IllegalArgumentException("Duration must be > 0.");

        String today = LocalDate.now().toString();
        String id    = UUID.randomUUID().toString().substring(0, 8);

        LearningSession session = new LearningSession(
                id, user.getUserId(), goalId, topicName, today,
                durationHours, masteryBefore, masteryAfter, sessionType, notes);

        fileManager.saveSession(session);

        // Update the topic's mastery level and lastStudied in storage
        List<Topic> allTopics = fileManager.loadTopics();
        allTopics.stream()
                .filter(t -> t.getGoalId().equals(goalId) && t.getName().equals(topicName))
                .forEach(t -> {
                    t.setMasteryLevel(masteryAfter);
                    t.setLastStudied(today);
                });
        fileManager.saveAllTopics(allTopics);

        // Habit record
        fileManager.saveHabitRecord(new HabitRecord(user.getUserId(), today, durationHours, 1));

        reload();
    }

    // ── Goal management ───────────────────────────────────────────────────────

    public void addGoal(LearningGoal goal, List<Topic> topics,
                        List<Milestone> milestones) throws IOException {
        fileManager.saveGoal(goal);

        List<Topic> existing = fileManager.loadTopics();
        existing.addAll(topics);
        fileManager.saveAllTopics(existing);

        List<Milestone> existingM = fileManager.loadMilestones();
        existingM.addAll(milestones);
        fileManager.saveAllMilestones(existingM);

        reload();
    }

    public void updateGoalStatus(String goalId, GoalStatus newStatus) throws IOException {
        List<LearningGoal> all = fileManager.loadGoals();
        all.stream().filter(g -> g.getGoalId().equals(goalId))
                .findFirst().ifPresent(g -> g.setStatus(newStatus));
        fileManager.saveAllGoals(all);
        reload();
    }

    // ── Assessment ────────────────────────────────────────────────────────────

    public void addAssessment(Assessment assessment) throws IOException {
        fileManager.saveAssessment(assessment);
        reload();
    }

    // ── Getters for Dashboard ─────────────────────────────────────────────────

    public User                  getUser()     { return user; }
    public List<LearningGoal>    getGoals()    { return goals; }
    public List<LearningSession> getSessions() { return sessions; }
    public EngineResult          getResult()   { return result; }
    public List<Insight>         getInsights() { return insights; }
}


